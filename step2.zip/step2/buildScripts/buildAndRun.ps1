npm i 
npm test