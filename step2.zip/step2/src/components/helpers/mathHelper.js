var mathHelpers = {
    roundCurrency(number){
        return Math.round(number * 100)/100;
    }
}

export default mathHelpers;