class product
{
    constructor(name, price)
    {
        this.name = name;
        this.price = price;
    }
}

export default product;